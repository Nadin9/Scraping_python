from bs4 import BeautifulSoup
import lxml

# with open('website.html') as file:
#     content = file.read()

# soup = BeautifulSoup(content, 'lxml') # or 'html.parser'

# print(soup.title)
# print(soup.title.name) #title
# print(soup.title.string) #Angela's Personal Site
# all_anchors =soup.find_all(name='a') #find all elements eith the tag named 'a' (all anchor tags)

# for tag in all_anchors:
#     print(tag.get('href')) # all links 

# # isolate an element
# heading = soup.find(name='h1', id='name')

# section_heading = soup.find(name='h3', class_='heading')

# # cs selector 
# company_url = soup.select_one(selector='p a') #get the a tag that's inside the p tag
# soup.select_one('#name') #the tag with id =name
# soup.select_one('.heading') #the tag with the class=heading

""" scraping a live website"""

import requests

# response = requests.get('https://news.ycombinator.com/')
# contents = response.text

# soup = BeautifulSoup(contents, 'lxml')
# add (/robots.txt) after the root link of a website to check if it aloows users to srap it

"""" scraping 100movies website and create txt file that includes movies names"""

response = requests.get('https://web.archive.org/web/20200518073855/https://www.empireonline.com/movies/features/best-movies-2/')
web_text= response.text

soup = BeautifulSoup(web_text, 'lxml')
movies=soup.find_all(name='h3', class_='title')
names= [movie.getText() for movie in movies]
movies_names = names[::-1]

with open('movies.txt', mode='w', encoding="utf-8") as file:
    for i in movies_names:
        file.write(f'{i}\n')

# <h3 class="title">100) Stand By Me</h3>